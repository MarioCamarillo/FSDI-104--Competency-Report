let student={
    /////////////
    //atributes
    ////////////
    name:"Daniel",
    age:99,
    isActive: true,


    //////////////////////
    // sayHi()
    //////////////////////
    sayHi:function(){
        return "hello";
    },
    hobbies:["Football","Listen Music","Play Zelda"],
    address:{
        street:"Palomar",
        zip:"22145",
        city:"San Diego",
        country:"USA"
    }

}

console.log(student.hobbies[1]);

/////////////////////////////////////////////////////////////////////////////
// Display the address in the console
/////////////////////////////////////////////////////////////////////////////
console.log(student.address.street, student.address.zip, student.address.country);


/////////////////////////////////////////////////////////////////////////////
// First product
/////////////////////////////////////////////////////////////////////////////

let products = [];

let product1={
    name:"laptop",
    description:"HP laptop 14'' corei7",
    price:200
}

let product2={
    name:"Desktop",
    description:"HP Desktop corei7",
    price:100
}

let product3={
    name:"mouse",
    description:"HP mouse",
    price:15
}



products.push(product1,product2,product3);



function displayNames(){
    for(let index=0;index<products.length;index++)
    console.log(products[index].description)
}

displayNames();