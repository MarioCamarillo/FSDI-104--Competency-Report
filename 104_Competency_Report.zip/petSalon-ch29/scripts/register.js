////////////////////////////////////////////////////////////
// Objet literal
////////////////////////////////////////////////////////////
let salon={
    name:"The Fashion Pet",
    address:{
        street:"Palomar",
        zip:"22345",
        city:"San Diego",
        number:"265-K"
    },
    hours:{
        open:"9:00 am",
        close:"5:00 pm"
    },
    phone:"555-555-555",
    
    pets:[]
}

//console.log(salon.pets[2]);



function displaySalonInfo(){
    for(index=0;index<salon.pets.length;index++)
    {
        document.getElementById("info").innerHTML=salon.pets.name;
    }
    
}

//displaySalonInfo();



///////////////////////////////////////////////////////////////////////////////////////////
// Create the pet constructor
// name, age, gender, breed, service, owner, phone
///////////////////////////////////////////////////////////////////////////////////////////
function pets(petsName,petsAge,petsGender,petsBreed,petsService,petsOwner,petsPhone){
    this.name=petsName;
    this.age=petsAge;
    this.gender=petsGender;
    this.breed=petsBreed;
    this.service=petsService;
    this.owner=petsOwner;
    this.phone=petsPhone;
}

//////////////////////////////////////////////////////////////////////////////////////////
// creating the new pets
//
/////////////////////////////////////////////////////////////////////////////////////////

let scooby = new pets("Scooby","12","Male","German Shepherd","Grooming","Shaggy","888-888-888");
let scrappy = new pets("Scrappy","5","Male","German something","bath","Shaggy","888-888-888");
let wolf = new pets("Wolf","4","Male","Husky","Grooming","DeVonte","212-338-8238");




///////////////////////////////////////////////////////////////////////////////////////////
// Validating pets
///////////////////////////////////////////////////////////////////////////////////////////
function isValid(aPet){
    let valid=true;
    if(aPet.Name=="" || aPet.Service=="" || aPet.Phone==""){
        //if we arrive here, the pet is not valid
        valid=false;
    }
    return valid;
}




function register(){
    console.log("Registering");

    //get the info from the inputs   ****get the elementById().value
    let petName = document.getElementById("txtName").value;
    let petAge = document.getElementById("txtAge").value;
    let petGender=document.getElementById("txtGender").value;
    let petBreed=document.getElementById("txtBreed").value;
    let petService=document.getElementById("selService").value;
    let petOwner=document.getElementById("txtOwner").value;
    let petPhone=document.getElementById("txtPhone").value;

    //create the object using the constructor
    let newPet =(petName,petAge,petGender,petBreed,petService,petOwner,petPhone);

    if(isValid(newPet)==true){

    //push the object into the array
    salon.pets.push(newPet);

    //display it on the console
    //console.log(petName,petAge,petGender,petBreed,petService,petOwner,petPhone);
    //display it on the HTML
    displayCards();


    //clear the form
    clear();
    }
    else{
        alert("Add a name for the pet");
    }
}

function clear(){
    //let inputs=document.getElementsByTagName('input');
    //let inputs=document.querySelector("input");
    //for(let index=0;index<inputs.length;index++){
    //    inputs[index].value="";   
    //}
    //document.getElementById("selService").value="default";
    $("input").val("");
    
}

function init(){
    displaySalonInfo();
    //salon.pets.push(scooby,scrappy);
    //console.log(scooby,scrappy);
    displayTable();

}

window.onload=init;