///////////////////////////////////////////////////////////////////////////////////////
// Display Pets Algorithm
// 1.- Create on the HTML a section or div or table, assign an ID
// 2.- The pets are salon.pets[], travel the array
// 3.- Create a template or card with the HTML code
// 4.- Append the card to the section that was created
///////////////////////////////////////////////////////////////////////////////////////


let tmp="";

function displayCards(){
    let petDiv = $("#pets");
    petDiv.html="";

    let tmp="";
    //travel the array
    for(let index=0;index<salon.pets.length;index++){
        let pets = salon.pets[index];
        tmp +=`
            <div class="pet">
              <h5>Name: ${pets.name}</h5>
               <p>Age: ${pets.age}</p>
               <p>Gender: ${pets.gender}</p>
               <p>Breed: ${pets.breed}</p>
               <p>Breed: ${pets.service}</p>
               <p>Breed: ${pets.owner}</p>
               <p>Breed: ${pets.phone}</p>
            </div>
            `;
    }
    petDiv.append(tmp);    
}

$("#pets").append(tmp);





function displayTable(){
    let table = $("#petsTable");
    table.html("");
    let tr="";

    for (let index=0;index<salon.pets.length;index++){
        let pets= salon.pets[index];
            tr=
            `
            <tr>
            <td>${pets.name}</td>
            <td>${pets.age}</td>
            <td>${pets.breed}</td>
            <td>${pets.service}</td>
            <td>${pets.owner}</td>
            <td>${pets.phone}</td>
            <tr>
            `;
            table.append(tr);
        }
     
}